# Kalshi NHL market history — zero-server pilot

A Python-standard-library collector snapshots **public Kalshi NHL game-winner markets** and their order books into SQLite. GitHub Actions runs it every two hours (UTC) and commits the database into this private repository.

## Start (about 2 minutes)

1. In your GitHub repository, choose **Add file → Upload files**.
2. Upload the *contents* of this package, preserving `.github/workflows/collect.yml`. GitHub's browser upload may not reliably preserve hidden folders; if it doesn't, create `.github/workflows/collect.yml` using **Add file → Create new file** and paste the workflow text.
3. Open **Actions → Collect Kalshi NHL snapshots → Run workflow**.
4. Check the run log for `status`, `active_markets`, and `books`; confirm `data/kalshi.sqlite` was committed.
5. In **Settings → Actions → General**, if required, set **Workflow permissions → Read and write permissions**. The workflow needs permission to commit the DB.

## What's collected

- Market metadata, bid/ask quotes, volume, open interest
- Full returned order-book levels up to 10 per side
- UTC capture timestamps, run status and API errors
- Closed-market results when encountered in the event scan

**Important:** The default series `KXNHLGAME` covers NHL game winners only. It does **not** automatically capture all totals, puck lines or player props. Additional verified Kalshi NHL series tickers can be set using the `KALSHI_SERIES` environment variable (comma-separated). Do not treat absent markets as nonexistent.

No prediction model, sportsbook lines, or EV calculation is included. This collector is market-data infrastructure, not a betting recommendation system. It does not trade or require Kalshi credentials.

## Configuration

Optional environment variables: `KALSHI_SERIES` (default `KXNHLGAME`), `MAX_EVENTS_PER_SERIES` (150), `MAX_MARKETS_PER_RUN` (400), `ORDERBOOK_DEPTH` (10), `KALSHI_DB` (`data/kalshi.sqlite`).

Run locally: `python collector.py` (Python 3.10+). No pip packages required.

## Practical limitations

- GitHub Actions scheduled jobs may be delayed or skipped. GitHub Actions free usage is subject to your account's plan and limits.
- Committing a binary SQLite database every two hours **grows Git history**. Suitable for a small pilot, not indefinite storage. Migrate to object storage or daily exports if the repository grows large.
- Public API endpoints and series tickers can change. A run with `no_active_books` is **not** evidence of no games; check API coverage and event discovery.
- Event pagination caps at 150 per series per run. The collector currently scans recent API pages, not guaranteed historical settlement completeness.
- SQLite snapshots are not live executable prices. Order books are captured at a point in time and can change before any trade.
- This has been syntax-checked but cannot be end-to-end tested against Kalshi's API in this build environment.
